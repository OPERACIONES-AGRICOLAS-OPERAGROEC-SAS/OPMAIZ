OPMAIZ — archivos para GitHub Pages

Sube estos dos archivos a la raíz de la rama principal:
- index.html
- logo.png

URL esperada del logo:
https://operagroec.github.io/OPMAIZ/logo.png

Cuenta X:
https://x.com/operagroec?s=11
